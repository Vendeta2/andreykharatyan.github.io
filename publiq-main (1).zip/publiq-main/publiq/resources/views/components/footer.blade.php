<footer>
    <div class="w-full bg-primary h-36 flex justify-center items-center text-2xl">
        <p><b>Copyright 2024©</b> Публикация Историй</p>
    </div>
</footer>
